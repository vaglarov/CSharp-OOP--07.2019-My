﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomStack
{
    public class Engine
    {
        public void Run()
        {
        
        }
    }
}
