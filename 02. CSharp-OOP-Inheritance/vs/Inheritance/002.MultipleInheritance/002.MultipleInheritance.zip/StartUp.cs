﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engien = new Engine();
            engien.Run();
        }
    }
}
