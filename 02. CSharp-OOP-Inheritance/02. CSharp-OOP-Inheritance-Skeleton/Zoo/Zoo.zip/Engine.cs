﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo
{
   public class Engine
    {
        public void Run()
        {
            Console.WriteLine("OK");
        }
    }
}
