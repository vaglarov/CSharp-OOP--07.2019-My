﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Enumerator
{
    public enum Corp
    {
        Airforces,
        Marines
    }
}
