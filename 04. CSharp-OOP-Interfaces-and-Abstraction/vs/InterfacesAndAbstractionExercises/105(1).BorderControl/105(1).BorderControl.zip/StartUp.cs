﻿using BorderControl2.Core;
using System;

namespace _105_1_.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
