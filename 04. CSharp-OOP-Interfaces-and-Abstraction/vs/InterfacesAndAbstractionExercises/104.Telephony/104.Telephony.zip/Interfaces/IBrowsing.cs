﻿namespace _104.Telephony.Interfaces
{
    public interface IBrowsing
    {
        string Browsing(string input);
    }
}
