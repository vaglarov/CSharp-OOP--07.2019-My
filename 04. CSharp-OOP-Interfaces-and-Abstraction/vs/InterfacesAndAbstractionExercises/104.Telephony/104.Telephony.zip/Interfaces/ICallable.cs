﻿namespace _104.Telephony.Interfaces
{
    public interface ICallable
    {
        string Calling(string input);

    }
}
