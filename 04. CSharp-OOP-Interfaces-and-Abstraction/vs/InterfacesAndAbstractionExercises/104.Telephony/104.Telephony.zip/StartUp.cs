﻿using _104.Telephony.Core;
using System;

namespace _104.Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
