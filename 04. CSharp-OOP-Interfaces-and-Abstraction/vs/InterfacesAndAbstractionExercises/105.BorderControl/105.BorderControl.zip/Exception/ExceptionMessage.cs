﻿namespace BorderControl.Exception
{
    public static class ExceptionMessage
    {
        public static string NameIsNulleOrEmpty = "Name cannot be empty";
        public static string ModelIsNulleOrEmpty = "Model cannot be empty";
        public static string AgeMustBeInt = "Age must be int";
    }
}
