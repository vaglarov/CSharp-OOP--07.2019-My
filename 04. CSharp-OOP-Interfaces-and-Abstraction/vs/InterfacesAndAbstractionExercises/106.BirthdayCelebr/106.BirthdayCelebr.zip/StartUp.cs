﻿using BirthdayCelebr.Core;
using System;

namespace BirthdayCelebr
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
