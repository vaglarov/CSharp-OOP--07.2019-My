﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebr.Interfaces
{
    public interface IPet : IItemWithBirthDate
    {
    }
}
