﻿using BirthdayCelebr.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebr.Interfaces
{
    interface ICitizenWihtBirthDate : ICitizen,IItemWithBirthDate
    {

    }
}
