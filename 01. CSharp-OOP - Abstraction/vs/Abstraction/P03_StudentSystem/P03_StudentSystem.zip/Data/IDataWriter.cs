﻿
namespace P03_StudentSystem
{
    public interface IDataWriter
    {
        void Write(object obj);
    }
}
