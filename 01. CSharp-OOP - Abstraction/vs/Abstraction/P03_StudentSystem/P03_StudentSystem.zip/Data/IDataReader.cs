﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_StudentSystem
{
   public interface IDataReader
    {
        string Read();
    }
}
