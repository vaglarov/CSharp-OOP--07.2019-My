﻿namespace WildFarm.ExceptionMessages
{
    public static class ExceptionMessage
    {
        public static string InvalidFoodType = "{0} does not eat {1}!";
    }
}
