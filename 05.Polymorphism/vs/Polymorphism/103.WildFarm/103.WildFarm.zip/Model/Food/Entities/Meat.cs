﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Model.Food.Entities
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
