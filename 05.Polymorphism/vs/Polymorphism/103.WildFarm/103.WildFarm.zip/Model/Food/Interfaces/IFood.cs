﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Model.Food.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
