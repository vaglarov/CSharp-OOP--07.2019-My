﻿namespace PizzaCalories.Enum
{
    public enum DoughCalloriesPerGram
    {
        White = 15,
        Wholegrain = 10,
        Crispy= 9,
        Chewy= 11,
        Homemade = 10
    }
}
