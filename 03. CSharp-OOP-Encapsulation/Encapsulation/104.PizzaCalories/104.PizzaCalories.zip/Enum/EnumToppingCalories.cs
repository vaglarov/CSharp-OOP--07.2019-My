﻿namespace PizzaCalories.Enum
{
    public enum EnumToppingCalories
    {
        Meat = 12,
        Veggies = 8,
        Cheese = 11,
        Sauce = 9
    }
}
