﻿
namespace ClassBoxData
{ 
using System;
  
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine test = new Engine();
            test.Run();
        }
    }
}
