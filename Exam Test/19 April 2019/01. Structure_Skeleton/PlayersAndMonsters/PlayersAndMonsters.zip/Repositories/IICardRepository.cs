﻿namespace PlayersAndMonsters.Repositories
{
    public class IICardRepository
    {
    }
}