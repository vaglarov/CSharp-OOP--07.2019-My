﻿using SoftUniRestaurant.Models.Drinks.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace SoftUniRestaurant.Models.Drinks.Factories
{
    public class DrinkFactory
    {
        //string name, int servingSize, decimal price, string brand
        public IDrink CreateDrink(string typeDrink, int servingSize, decimal price, string brand)
        {
            Type typeClass = Assembly.GetCallingAssembly()
                .GetTypes()
                .FirstOrDefault(t => t.Name == typeDrink);

            IDrink food = (IDrink)Activator.CreateInstance(
                typeClass, servingSize,price,brand);
            return food;
        }
    }
}
