﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.Core.Contracts
{
   public interface ICommand
    {

    }
}
